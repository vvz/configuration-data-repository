
class WebtestGrailsPlugin {
	def version = 0.3
	def dependsOn = [core:'1.0-RC1'] 
	def title = "A plug-in that provides functional testing for Grails using Canoo Web Test"
	def author = "Dierk Koenig"
	def authorEmail = "dierk.koenig at canoo.com"
	def description = title
}
